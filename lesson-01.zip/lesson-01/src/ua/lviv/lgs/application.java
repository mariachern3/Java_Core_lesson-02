package ua.lviv.lgs;

import java.util.Arrays;
import java.util.Collections;

public class application {

	public static void main(String[] args) {

//	byte b = 1;
//	short sh = 2;
//	int a = 5;
//	long l = 100000;
//	float f = 1.5f;
//	double d = 4.3;
//	char c = '2';
//	boolean bb = true;

		System.out.println("byte = " + Byte.MAX_VALUE);
		System.out.println("byte = " + Byte.MIN_VALUE);
		System.out.println("short = " + Short.MAX_VALUE);
		System.out.println("short = " + Short.MIN_VALUE);
		System.out.println("int = " + Integer.MAX_VALUE);
		System.out.println("int = " + Integer.MIN_VALUE);
		System.out.println("long = " + Long.MAX_VALUE);
		System.out.println("long = " + Long.MIN_VALUE);
		System.out.println("float = " + Float.MAX_VALUE);
		System.out.println("float = " + Float.MIN_VALUE);
		System.out.println("double = " + Double.MAX_VALUE);
		System.out.println("double = " + Double.MIN_VALUE);
		System.out.println("char: " + (Character.MAX_VALUE + 0));
		System.out.println("char = " + (int) Character.MIN_VALUE);

		Integer[] num = { 3, 2, 1, 4, 7, 5, 9 };

		int min = Collections.min(Arrays.asList(num));

		int max = Collections.max(Arrays.asList(num));

		System.out.println("Minimum number of array is : " + min);
		System.out.println("Maximum number of array is : " + max);
	}

}
